var searchData=
[
  ['jumpbackward_3a_89',['jumpBackward:',['../interface_v_l_c_media_player.html#a86d420386d6dde28818ae2a7e56f6198',1,'VLCMediaPlayer']]],
  ['jumpforward_3a_90',['jumpForward:',['../interface_v_l_c_media_player.html#a51e8067be7f55f64d3cfa3e4acccfafc',1,'VLCMediaPlayer']]]
];
